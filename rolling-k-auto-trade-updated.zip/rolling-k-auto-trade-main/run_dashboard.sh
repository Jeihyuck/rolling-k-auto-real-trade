#!/bin/bash
streamlit run auto_trade_dashboard/dashboard_app.py --server.port 8501
